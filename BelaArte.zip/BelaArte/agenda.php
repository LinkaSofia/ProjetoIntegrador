<?php
session_start();
include_once("conexao2.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8' />
        <link href="assets/css/estilo.css" rel="stylesheet">
        <link href='assets/css/core/main.min.css' rel='stylesheet' />
        <link href='assets/css/daygrid/main.min.css' rel='stylesheet' />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/personalizado.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        


        <script src='assets/js/core/main.min.js'></script>
        <script src='assets/js/interaction/main.min.js'></script>
        <script src='assets/js/daygrid/main.min.js'></script>
        <script src='assets/js/core/locales/pt-br.js'></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script src="assets/js/personalizado.js"></script>
    </head>
    <header>
            <!-- Header -->
            <section id="header">
                <nav id="nav">
                    <ul>
                        <img src="assets/images/logo3.png" width="15%" height="110" id="logo1">
                        <li><a href="agenda.php">Agenda</a></li>
                        <li><a href="cadastrofuncionario.php">Cadastros</a></li>
                    </ul>
                </nav>
            </section>
    </header>
    <body>
        <div class = "container">
                    <h1 class="h1"> </h1>
        <div class="left">
            <div id="navVertical">
                <ul>
                    <li><a href="#">Agenda</a></li>
                    <li><a href="./form.php">Pesquisar Agenda</a></li>
                </ul>
            </div>
        </div>
        <?php
        if (isset($_SESSION['msg'])) {
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>

        <div id='calendar'></div>

        <div class="modal fade body2" id="visualizar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Detalhes do Agendamento</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="visevent">
                            <dl class="row">
                    
                                <dt class="col-sm-3">Nome do Cliente</dt>
                                <dd class="col-sm-9" id="NomeCliente"></dd>

                                <dt class="col-sm-3">Serviço</dt>
                                <dd class="col-sm-9" id="Servico"></dd>

                                <dt class="col-sm-3">Funcionário</dt>
                                <dd class="col-sm-9" id="funcionario"></dd>

                                <dt class="col-sm-3">Início do atendimento</dt>
                                <dd class="col-sm-9" id="start"></dd>

                                <dt class="col-sm-3">Fim do atendimento</dt>
                                <dd class="col-sm-9" id="end"></dd>
                            </dl>
                            <button class="btn btn-warning btn-canc-vis">Editar</button>
                            <a href="" id="apagar_evento" class="btn btn-danger">Apagar</a>
                        </div>
                        <div class="formedit">
                            <span id="msg-edit"></span>
                            <form id="editevent" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="id" id="id" >
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Cliente *</label>
                                    <div class="col-sm-10">
                                        <select name="NomeCliente">
                                            <option>Selecione</option>
                                            <?php
                                                $result_niveis_acessos = "SELECT * FROM cliente";
                                                $resultado_niveis_acesso = mysqli_query($conn, $result_niveis_acessos);
                                                while($row_niveis_acessos = mysqli_fetch_assoc($resultado_niveis_acesso)){ ?>
                                            <option value="<?php echo $row_niveis_acessos['id']; ?>"><?php echo $row_niveis_acessos['nome']; ?></option> <?php }
                                            ?>
                                        </select><br><br>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Serviço *</label>
                                    <div class="col-sm-10">
                                        <select name="Servico">
                                            <option>Selecione</option>
                                            <?php
                                                $result_serv = "SELECT * FROM servico";
                                                $resultado_serv = mysqli_query($conn, $result_serv);
                                                while($row_serv = mysqli_fetch_assoc($resultado_serv)){ ?>
                                            <option value="<?php echo $row_serv['id']; ?>"><?php echo $row_serv['descricao']; ?></option> <?php }
                                            ?>
                                        </select><br><br>
                                        
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Funcionário *</label>
                                    <div class="col-sm-10">
                                        <select name="funcionario">
                                            <option>Selecione</option>
                                            <?php
                                                $result_func = "SELECT * FROM funcionario";
                                                $resultado_func = mysqli_query($conn, $result_func);
                                                while($row_func = mysqli_fetch_assoc($resultado_func)){ ?>
                                            <option value="<?php echo $row_func['id']; ?>"><?php echo $row_func['nome']; ?></option> <?php }
                                            ?>
                                        </select><br><br>
                                        
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Início do atendimento *</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="start" class="form-control" id="start" onkeypress="DataHora(event, this)">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Final do atendimento *</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="end" class="form-control" id="end"  onkeypress="DataHora(event, this)">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="button" class="btn btn-primary btn-canc-edit">Cancelar</button>
                                        <button type="submit" name="CadEvent" id="CadEvent" value="CadEvent" class="btn btn-warning">Salvar</button>                                    
                                    </div>
                                </div>
                            </form>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="cadastrar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Agendar</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <span id="msg-cad"></span>
                        <form id="addevent" method="POST" enctype="multipart/form-data">
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Cliente *</label>
                                    <div class="col-sm-10">
                                        <!--<input type="text" name="NomeCliente" class="form-control" id="NomeCliente" placeholder="Cliente">-->
                                        <select name="NomeCliente">
                                            <option required>Selecione</option>
                                            <?php
                                                $result_niveis_acessos = "SELECT * FROM cliente";
                                                $resultado_niveis_acesso = mysqli_query($conn, $result_niveis_acessos);
                                                while($row_niveis_acessos = mysqli_fetch_assoc($resultado_niveis_acesso)){ ?>
                                            <option value="<?php echo $row_niveis_acessos['id']; ?>"><?php echo $row_niveis_acessos['nome']; ?></option> <?php }
                                            ?>
                                        </select><br><br>
                                    </div>
                                </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Serviço *</label>
                                <div class="col-sm-10">
                                    <select name="Servico">
                                            <option>Selecione</option>
                                            <?php
                                                $result_serv = "SELECT * FROM servico";
                                                $resultado_serv = mysqli_query($conn, $result_serv);
                                                while($row_serv = mysqli_fetch_assoc($resultado_serv)){ ?>
                                            <option value="<?php echo $row_serv['id']; ?>"><?php echo $row_serv['descricao']; ?></option> <?php }
                                            ?>
                                        </select><br><br>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Funcionário *</label>
                                <div class="col-sm-10">
                                    <select name="funcionario">
                                            <option>Selecione</option>
                                            <?php
                                                $result_func = "SELECT * FROM funcionario";
                                                $resultado_func = mysqli_query($conn, $result_func);
                                                while($row_func = mysqli_fetch_assoc($resultado_func)){ ?>
                                            <option value="<?php echo $row_func['id']; ?>"><?php echo $row_func['nome']; ?></option> <?php }
                                            ?>
                                        </select><br><br>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Início do atendimento *</label>
                                <div class="col-sm-10">
                                    <input type="text" name="start" class="form-control" id="start" onkeypress="DataHora(event, this)">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Final do atendimento *</label>
                                <div class="col-sm-10">
                                    <input type="text" name="end" class="form-control" id="end"  onkeypress="DataHora(event, this)">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" name="CadEvent" id="CadEvent" value="CadEvent" class="btn btn-success">Cadastrar</button>                                    
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
