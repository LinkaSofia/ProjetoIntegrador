<?php
session_start();
include_once("./conexao2.php");
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if(!empty($id)){
    $result_nivel_acesso = "DELETE FROM nivel_acesso WHERE id='$id'";
    $resultado_nivel_acesso = mysqli_query($conn, $result_nivel_acesso);
    if(mysqli_affected_rows($conn)){
        $_SESSION['msg'] = "<p style='color:green;'>Nível de acesso apagado com sucesso</p>";
        header("Location: cadastro_nivel_acesso.php");
    }else{
        
        $_SESSION['msg'] = "<p style='color:red;'>Erro, o Nível de acesso não foi apagado com sucesso</p>";
        header("Location: cadastro_nivel_acesso.php");
    }
}else{  
    $_SESSION['msg'] = "<p style='color:red;'>Necessário selecionar um Nível de acesso</p>";
    header("Location: cadastro_nivel_acesso.php");
}
