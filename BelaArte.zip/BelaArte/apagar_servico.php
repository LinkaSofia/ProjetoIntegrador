<?php
session_start();
include_once("./conexao2.php");
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if(!empty($id)){
    $result_serv = "DELETE FROM servico WHERE id='$id'";
    $resultado_serv = mysqli_query($conn, $result_serv);
    if(mysqli_affected_rows($conn)){
        $_SESSION['msg'] = "<p style='color:green;'>Serviço apagado com sucesso</p>";
        header("Location: cadastraServico.php");
    }else{
        
        $_SESSION['msg'] = "<p style='color:red;'>Erro, o serviço não foi apagado com sucesso</p>";
        header("Location: cadastraServico.php");
    }
}else{  
    $_SESSION['msg'] = "<p style='color:red;'>Necessário selecionar um usuário</p>";
    header("Location: cadastraServico.php");
}
