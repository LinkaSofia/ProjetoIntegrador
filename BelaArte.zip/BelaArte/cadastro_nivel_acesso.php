<?php
	session_start();
	include_once("conexao2.php");
?>
<!DOCTYPE html>
<html lang = "pt-br">
<head>
	<meta charset="utf-8">
	<title> Cadastrar Níveis de Acesso </title>
	<link href="assets/css/estilo.css" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<header>
        <!-- Header -->
        <section id="header">
            <nav id="nav">
                <ul>
                    <img src="assets/images/logo3.png" width="15%" height="110" id="logo1">
                    <li><a href="agenda.php">Agenda</a></li>
                    <li><a href="cadastrofuncionario.php">Cadastros</a></li>
                </ul>
            </nav>
        </section>
</header>
<body>
	<div class = "container">
		<h1 class="h1">Cadastrar Níveis de Acesso </h1>
		<div class="left">
			<div id="navVertical">
				<ul>
			    	<li><a href="./cadastrofuncionario.php">Funcionário</a></li>
			    	<li><a href="./cadastroCliente.php">Cliente</a></li>
			    	<li><a href="./cadastraServico.php">Serviços</a></li>
			    	<li><a href="#">Fornecedor</a></li>
			    	<li><a href="#">Produto</a></li>
			    	<li><a href="#">Níveis de Acesso</a></li>
			  	</ul>
		  	</div>
	  	</div>
		<?php
			if (isset($_SESSION['msgfunc'])) {
				echo $_SESSION['msgfunc'];	
				//Destruir a variavel logo após o uso
				unset($_SESSION['msgfunc']);
			}	
		?>
		<div class="right">
			<form method = "POST" action = "processa_niveis_acesso.php">
				<label>Nome: *</label>
				<input type= "text" name = "nome" placeholder = "Digite o nível de acesso" required></br></br>

				<input type = "submit" value = "Cadastrar"> 
			</form>
		</div>
	
		<div>
			<h1 class="h1 h1_4"> Lista de Níveis de Acesso</h1>
			<span id="conteudo"></span><br><br><br>
			<div id="visulUsuarioModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="visulUsuarioModalLabel">Níveis de Acesso</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  		<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<span id="visul_usuario"></span>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-outline-info" data-dismiss="modal">Fechar</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
			var qnt_result_pg = 50; //quantidade de registro por página
			var pagina = 1; //página inicial
			$(document).ready(function () {
				listar_niveis_acessos(pagina, qnt_result_pg); //Chamar a função para listar os registros
			});
				
			function listar_niveis_acessos(pagina, qnt_result_pg){
				var dados = {
					pagina: pagina,
					qnt_result_pg: qnt_result_pg
				}
				$.post('listar_niveis_acessos.php', dados , function(retorna){
					//Subtitui o valor no seletor id="conteudo"
					$("#conteudo").html(retorna);
				});
			}
			
		</script>
	</div>
</body>
<html>

