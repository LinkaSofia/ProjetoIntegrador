<?php
	session_start();
	include_once("conexao2.php");
?>
<!DOCTYPE html>
<html lang = "pt-br">
<head>
	<meta charset="utf-8">
	<title> Cadastrar funcionario </title>
	<link href="assets/css/estilo.css" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<header>
        <!-- Header -->
        <section id="header">
            <nav id="nav">
                <ul>
                    <img src="assets/images/logo3.png" width="15%" height="110" id="logo1">
                    <li><a href="agenda.php">Agenda</a></li>
                    <li><a href="cadastrofuncionario.php">Cadastros</a></li>
                </ul>
            </nav>
        </section>
</header>
<body>
	<div class = "container">
		<h1 class="h1"> Cadastrar Funcionários</h1>
		<div class="left">
			<div id="navVertical">
				<ul>
			    	<li><a href="#">Funcionário</a></li>
			    	<li><a href="./cadastroCliente.php">Cliente</a></li>
			    	<li><a href="./cadastraServico.php">Serviços</a></li>
			    	<li><a href="#">Fornecedor</a></li>
			    	<li><a href="#">Produto</a></li>
			    	<li><a href="./cadastro_nivel_acesso.php">Níveis de Acesso</a></li>
			  	</ul>
		  	</div>
	  	</div>
		<?php
			if (isset($_SESSION['msgfunc'])) {
				echo $_SESSION['msgfunc'];	
				//Destruir a variavel logo após o uso
				unset($_SESSION['msgfunc']);
			}	
		?>
		<div class="right">
			<form method = "POST" action = "processa.php">
				<label>Nome: *</label>
				<input type= "text" name = "nome" placeholder = "Digite o nome completo" required></br></br>

				<label>Email: </label>
				<input type= "email" name = "email" placeholder = "Digite o email"></br></br>

				<label>Senha: </label>
				<input type= "text" name = "senha" placeholder = "Digite a senha"></br></br>

				<label>Telefone: *</label>
				<input type= "text" name = "tel" placeholder = "Digite o telefone" required></br></br>

				<label>Dia e Mês de Aniversário: </label>
				<input type= "text" name = "diames" placeholder = "Digite o dia e mês de aniversário"></br></br>

				<label>Nivel de Acesso: *</label>
				 <select name="nivel_acesso" required>
                    <option>Selecione</option>
                    <?php
                        $result_niveis_acessos = "SELECT * FROM nivel_acesso";
                        $resultado_niveis_acesso = mysqli_query($conn, $result_niveis_acessos);
                        while($row_niveis_acessos = mysqli_fetch_assoc($resultado_niveis_acesso)){ ?>
                    <option value="<?php echo $row_niveis_acessos['id']; ?>"><?php echo $row_niveis_acessos['nome']; ?></option> <?php }
                    ?>
                </select><br><br>


				<input type = "submit" value = "Cadastrar"> 
			</form>
		</div>
	
		<div>
			<h1 class="h1 h1_2"> Lista de Funcionários</h1>
			<span id="conteudo"></span><br><br><br>
			<div id="visulUsuarioModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="visulUsuarioModalLabel">Detalhes dos Clientes</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  		<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<span id="visul_usuario"></span>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-outline-info" data-dismiss="modal">Fechar</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
			var qnt_result_pg = 50; //quantidade de registro por página
			var pagina = 1; //página inicial
			$(document).ready(function () {
				listar_funcionarios(pagina, qnt_result_pg); //Chamar a função para listar os registros
			});
				
			function listar_funcionarios(pagina, qnt_result_pg){
				var dados = {
					pagina: pagina,
					qnt_result_pg: qnt_result_pg
				}
				$.post('listar_funcionarios.php', dados , function(retorna){
					//Subtitui o valor no seletor id="conteudo"
					$("#conteudo").html(retorna);
				});
			}

		</script>
	</div>
</body>
<html>

