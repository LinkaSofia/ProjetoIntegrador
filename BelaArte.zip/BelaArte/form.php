<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8' />
		<link href="assets/css/estilo.css" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    </head>
        <header>
            <!-- Header -->
            <section id="header">
                <nav id="nav">
                    <ul>
                        <img src="assets/images/logo3.png" width="15%" height="110" id="logo1">
                        <li><a href="agenda.php">Agenda</a></li>
                        <li><a href="cadastrofuncionario.php">Cadastros</a></li>
                    </ul>
                </nav>
            </section>
    </header>
    <body>
    	<div class = "container">
		<h1 class="h1"> Pesquisar Atendimento</h1>
		<div class="left">
			<div id="navVertical">
				<ul>
			    	<li><a href="./agenda.php">Agenda</a></li>
			    	<li><a href="#">Pesquisar Agenda</a></li>
			  	</ul>
		  	</div>
	  	</div>
    	<div class="right">
			<form method="POST" action="pesquisar_agenda.php">
				Cliente: <input type="text" name="cliente" placeholder="Nome do Cliente"><br><br>
				Funcionário: <input type="text" name="funcionario" placeholder="Nome do Funcionário"><br><br>
				Serviço: <input type="text" name="servico" placeholder="Serviço"><br><br>
				<input type="submit" value="Pesquisar">
			</form>
		</div>
		<div>
			<h1 class="h1 h1_2"> Agendamentos</h1>
			<span id="conteudo"></span><br><br><br>
			<div id="visulUsuarioModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="visulUsuarioModalLabel">Detalhes do Agendamento</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  		<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<span id="visul_usuario"></span>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-outline-info" data-dismiss="modal">Fechar</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
			var qnt_result_pg = 50; //quantidade de registro por página
			var pagina = 1; //página inicial
			$(document).ready(function () {
				pesquisar_agenda(pagina, qnt_result_pg); //Chamar a função para listar os registros
			});
				
			function pesquisar_agenda(pagina, qnt_result_pg){
				var dados = {
					pagina: pagina,
					qnt_result_pg: qnt_result_pg
				}
				$.post('pesquisar_agenda.php', dados , function(retorna){
					//Subtitui o valor no seletor id="conteudo"
					$("#conteudo").html(retorna);
				});
			}
		</script>
</body>
<html>

