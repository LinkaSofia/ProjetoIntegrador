<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Salão de Beleza</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/estilo.css">
</head>
<body>
		<div>
			<!-- Header -->
			<section id="header">
				<nav id="nav">
					<ul>
						<img src="assets/images/logo3.png" width="15%" height="110" id="logo1">
						<li><a href="agenda.php">Agenda</a></li>
						<li><a href="cadastrofuncionario.php">Cadastros</a></li>
					</ul>
				</nav>
			</section>
		</div>
		<div>
			<img src="assets/images/img1.jpg" width="100%" height="640">
		</div>
	</body>
</html>