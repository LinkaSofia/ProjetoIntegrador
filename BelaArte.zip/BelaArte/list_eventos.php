<?php
include 'conexao.php';

$query_events = "SELECT 
    a.id as id, 
    a.cliente as idcliente, 
    a.Servico as idservico,
    a.funcionario as idfuncionario,
    c.nome as cliente, 
    s.descricao as Servico, 
    f.nome as funcionario, 
    dtInicio, 
    dtFim 
FROM atendimento a
LEFT JOIN cliente c ON
    a.cliente = c.id
LEFT JOIN servico s ON
    a.Servico = s.id
LEFT JOIN funcionario f ON
    a.funcionario = f.id
";
$resultado_events = $conn->prepare($query_events);
$resultado_events->execute();

$eventos = [];

while($row_events = $resultado_events->fetch(PDO::FETCH_ASSOC)){
    $id = $row_events['id'];
    $idcliente = $row_events['idcliente'];
    $idservico = $row_events['idservico'];
    $idfuncionario = $row_events['idfuncionario'];
    $NomeCliente = $row_events['cliente'];
    $funcionario = $row_events['funcionario'];
    $Servico = $row_events['Servico'];
    $start = $row_events['dtInicio'];
    $end = $row_events['dtFim'];
    
    $eventos[] = [
        'id' => $id, 
        'idcliente' => $idcliente, 
        'idservico' => $idservico, 
        'idfuncionario' => $idfuncionario, 
        'NomeCliente' => $NomeCliente, 
        'funcionario' => $funcionario, 
        'Servico' => $Servico, 
        'start' => $start, 
        'end' => $end, 
        ];
}

echo json_encode($eventos);

?>