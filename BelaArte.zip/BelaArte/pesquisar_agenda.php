<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8' />
		<link href="assets/css/estilo.css" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    </head>
        <header>
            <!-- Header -->
            <section id="header">
                <nav id="nav">
                    <ul>
                        <img src="assets/images/logo3.png" width="15%" height="110" id="logo1">
                        <li><a href="agenda.php">Agenda</a></li>
                        <li><a href="cadastrofuncionario.php">Cadastros</a></li>
                    </ul>
                </nav>
            </section>
    </header>
<body>
	<?php
		include_once './conexao2.php';

		$verifica = 0;
		$cliente = $_POST['cliente'];
		$funcionario = $_POST['funcionario'];
		$servico = $_POST['servico'];
		
		
		if(!empty($_POST['cliente']) && !empty($_POST['funcionario']) && !empty($_POST['servico'])){
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE cli.nome LIKE '%$cliente%' and f.nome LIKE '%$funcionario%' and s.descricao LIKE '%$servico%'";
			$resultado_agenda = mysqli_query($conn, $result_agenda);
			$verifica = mysqli_num_rows($resultado_agenda);
		}elseif(!empty($_POST['cliente']) && !empty($_POST['funcionario'])){		
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE cli.nome LIKE '%$cliente%' and  f.nome LIKE '%$funcionario%' ";
			$resultado_agenda = mysqli_query($conn, $result_agenda);	
			$verifica = mysqli_num_rows($resultado_agenda);	
		}elseif(!empty($_POST['cliente']) && !empty($_POST['servico'])){		
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE cli.nome LIKE '%$cliente%' and s.descricao LIKE '%$servico%' ";
			$resultado_agenda = mysqli_query($conn, $result_agenda);	
			$verifica = mysqli_num_rows($resultado_agenda);	
		}elseif(!empty($_POST['funcionario']) && !empty($_POST['servico'])){		
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE f.nome LIKE '%$funcionario%' and s.descricao LIKE '%$servico%' ";
			$resultado_agenda = mysqli_query($conn, $result_agenda);	
			$verifica = mysqli_num_rows($resultado_agenda);	
		}elseif(!empty($_POST['cliente'])){		
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE cli.nome LIKE '%$cliente%'";
			$resultado_agenda = mysqli_query($conn, $result_agenda);		
			$verifica = mysqli_num_rows($resultado_agenda);
		}elseif(!empty($_POST['funcionario'])){		
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE f.nome LIKE '%$funcionario%'";
			$resultado_agenda = mysqli_query($conn, $result_agenda);	
			$verifica = mysqli_num_rows($resultado_agenda);	
		}elseif(!empty($_POST['servico'])){		
			$result_agenda = "SELECT 
								cli.nome as cliente,
	    						f.nome as funcionario,
	    						s.descricao as servico,
	    						a.dtInicio as Inicio,
	                            a.dtFim as Fim
							FROM atendimento a
							LEFT JOIN cliente cli ON
								a.cliente = cli.id
							LEFT JOIN funcionario f ON
								a.funcionario = f.id
							LEFT JOIN servico s ON
	    						a.Servico = s.id
							WHERE s.descricao LIKE '%$servico%'";
			$resultado_agenda = mysqli_query($conn, $result_agenda);	
			$verifica = mysqli_num_rows($resultado_agenda);	
		}
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Cliente</th>
					<th>Funcionário</th>
					<th>Serviço</th>
					<th>Início do atendimento</th>
					<th>Fim do atendimento</th>
				</tr>
			</thead>
			<tbody>
		<?php
		
		if($verifica > 0){
			while($rows_agenda = mysqli_fetch_array($resultado_agenda)){
				?>
				<tr>
						<th><?php echo $rows_agenda['cliente']; ?></th>
						<td><?php echo $rows_agenda['funcionario']; ?></td>
						<td><?php echo $rows_agenda['servico']; ?></td>
						<td><?php echo $rows_agenda['Inicio']; ?></td>
						<td><?php echo $rows_agenda['Fim']; ?></td>		

					</tr>
					</tr>
				<?php }} ?>
			</tbody>
		</table>
	</body>
</html>