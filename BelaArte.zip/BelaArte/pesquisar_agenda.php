<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "bela_arte";
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
	?>
	<a href="form.php">Voltar</a><br><br><?php
	$verifica = 0;
	$cliente = $_POST['cliente'];
	$funcionario = $_POST['funcionario'];
	$servico = $_POST['servico'];
	
	if(!empty($_POST['cliente']) && !empty($_POST['funcionario']) && !empty($_POST['servico'])){
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE cli.nome LIKE '%$cliente%' and f.nome LIKE '%$funcionario%' and s.descricao LIKE '%$servico%'";
		$resultado_cursos = mysqli_query($conn, $result_cursos);
		$verifica = mysqli_num_rows($resultado_cursos);
	}elseif(!empty($_POST['cliente'])){		
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE cli.nome LIKE '%$cliente%'";
		$resultado_cursos = mysqli_query($conn, $result_cursos);		
		$verifica = mysqli_num_rows($resultado_cursos);
	}elseif(!empty($_POST['funcionario'])){		
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE f.nome LIKE '%$funcionario%'";
		$resultado_cursos = mysqli_query($conn, $result_cursos);	
		$verifica = mysqli_num_rows($resultado_cursos);	
	}elseif(!empty($_POST['servico'])){		
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE s.descricao LIKE '%$servico%'";
		$resultado_cursos = mysqli_query($conn, $result_cursos);	
		$verifica = mysqli_num_rows($resultado_cursos);	
	}elseif(!empty($_POST['cliente']) && !empty($_POST['funcionario'])){		
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE cli.nome LIKE '%$cliente%' and  f.nome LIKE '%$funcionario%' ";
		$resultado_cursos = mysqli_query($conn, $result_cursos);	
		$verifica = mysqli_num_rows($resultado_cursos);	
	}elseif(!empty($_POST['cliente']) && !empty($_POST['servico'])){		
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE cli.nome LIKE '%$cliente%' and s.descricao LIKE '%$servico%' ";
		$resultado_cursos = mysqli_query($conn, $result_cursos);	
		$verifica = mysqli_num_rows($resultado_cursos);	
	}elseif(!empty($_POST['funcionario']) && !empty($_POST['servico'])){		
		$result_cursos = "SELECT 
							cli.nome as cliente,
    						f.nome as funcionario,
    						s.descricao as servico,
    						a.dtInicio as Inicio,
                            a.dtFim as Fim
						FROM atendimento a
						LEFT JOIN cliente cli ON
							a.cliente = cli.id
						LEFT JOIN funcionario f ON
							a.funcionario = f.id
						LEFT JOIN servico s ON
    						a.Servico = s.id
						WHERE f.nome LIKE '%$funcionario%' and s.descricao LIKE '%$servico%' ";
		$resultado_cursos = mysqli_query($conn, $result_cursos);	
		$verifica = mysqli_num_rows($resultado_cursos);	
	}
	
	if($verifica > 0){
		while($rows_cursos = mysqli_fetch_array($resultado_cursos)){
			echo "Cliente: ".$rows_cursos['cliente']."<br>";
			echo "Funcionário: ".$rows_cursos['funcionario']."<br>";
			echo "Serviço: ".$rows_cursos['servico']."<br>";
			echo "Inicio: ".$rows_cursos['Inicio']."<br>";
			echo "Fim: ".$rows_cursos['Fim']."<br>";
		}
	}else{
		echo "Nenhum curso encontrado na pesquisa";
	}
	
	
?>