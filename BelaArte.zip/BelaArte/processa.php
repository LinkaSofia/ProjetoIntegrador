<?php
session_start();
include_once("conexao2.php");

$email = filter_input(INPUT_POST, 'email',FILTER_SANITIZE_STRING);
$nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
$tel = filter_input(INPUT_POST, 'tel',FILTER_SANITIZE_STRING);
$diames = filter_input(INPUT_POST, 'diames',FILTER_SANITIZE_STRING);
$senha = filter_input(INPUT_POST, 'senha',FILTER_SANITIZE_STRING);
$nivel_acesso = filter_input(INPUT_POST, 'nivel_acesso',FILTER_SANITIZE_STRING);



/*echo "TESTE: $email";*/

$result_func = "INSERT INTO funcionario(email, nome, telefone, dia_mes_nasc, senha, nivel_acesso) VALUES ('$email', '$nome', '$tel', '$diames', '$senha', '$nivel_acesso')";

if ($conn->query($result_func) == TRUE) {
	echo "Usuário incluído";
	header("Location: cadastrofuncionario.php");
} else {
	echo "Erro: " . $result_func . "<br>" . $conn->error;
}
$conn->close();
?>