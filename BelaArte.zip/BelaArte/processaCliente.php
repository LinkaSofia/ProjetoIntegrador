<?php
session_start();
include_once("conexao2.php");

$id = filter_input(INPUT_POST, 'id',FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email',FILTER_SANITIZE_STRING);
$nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
$senha = filter_input(INPUT_POST, 'senha',FILTER_SANITIZE_STRING);
$tel = filter_input(INPUT_POST, 'tel',FILTER_SANITIZE_STRING);
$diames = filter_input(INPUT_POST, 'diames',FILTER_SANITIZE_STRING);

$result_cliente = "INSERT INTO cliente(id, email, nome, senha, telefone, dia_mes_nasc) VALUES ('$id', '$email', '$nome', '$senha', '$tel', '$diames')";
$resultado_cliente = mysqli_query($conn,$result_cliente);

if (mysqli_insert_id($conn)) {
	$_SESSION['msg'] = "<p style = 'color: green;'>Cliente cadastrado com sucesso</p>";
	header("Location: cadastroCliente.php");
} else {
	$_SESSION['msg'] = "<p style = 'color: red;'>Cliente não cadastrado</p>";
	header("Location: cadastroCliente.php");
}
?>