<?php
session_start();
include_once("conexao2.php");

$id = filter_input(INPUT_POST, 'id',FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email',FILTER_SANITIZE_STRING);
$nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
$senha = filter_input(INPUT_POST, 'senha',FILTER_SANITIZE_STRING);
$tel = filter_input(INPUT_POST, 'tel',FILTER_SANITIZE_STRING);

/*echo "TESTE: $email";*/

$result_usuario = "INSERT INTO cliente(id, email, nome, senha, telefone) VALUES ('$id', '$email', '$nome', '$senha', '$tel')";
$resultado_usuario = mysqli_query($conn,$result_usuario);

if (mysqli_insert_id($conn)) {
	$_SESSION['msg'] = "<p style = 'color: green;'>Serviço cadastrado com sucesso</p>";
	header("Location: cadastroCliente.php");
} else {
	$_SESSION['msg'] = "<p style = 'color: red;'>Serviço não cadastrado</p>";
	header("Location: cadastroCliente.php");
}
?>