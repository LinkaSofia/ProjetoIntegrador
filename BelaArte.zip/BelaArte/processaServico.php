<?php
session_start();
include_once("conexao2.php");

$desc = filter_input(INPUT_POST, 'desc',FILTER_SANITIZE_STRING);
$val = filter_input(INPUT_POST, 'val',FILTER_SANITIZE_STRING);

/*echo "TESTE: $email";*/

$result_serv = "INSERT INTO servico(descricao, valor) VALUES ('$desc', '$val')";
$resultado_serv = mysqli_query($conn,$result_serv);

if (mysqli_insert_id($conn)) {
	$_SESSION['msg'] = "<p style = 'color: green;'>Serviço cadastrado com sucesso</p>";
	header("Location: cadastraServico.php");

} else {
	$_SESSION['msg'] = "<p style = 'color: red;'>Serviço não cadastrado</p>";
	header("Location: cadastraServico.php");
}
?>