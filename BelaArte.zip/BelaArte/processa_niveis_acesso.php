processa_niveis_acesso<?php
session_start();
include_once("conexao2.php");

$nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);

$result_func = "INSERT INTO nivel_acesso(nome) VALUES ('$nome')";

if ($conn->query($result_func) == TRUE) {
	echo "Nível de Acesso Cadastrado";
	header("Location: cadastro_nivel_acesso.php");
} else {
	echo "Erro: " . $result_func . "<br>" . $conn->error;
}
$conn->close();
?>